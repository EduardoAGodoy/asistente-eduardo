import { GoogleGenAI, LiveSession, LiveServerMessage, Modality, FunctionDeclaration, Type, ToolCall, Blob } from '@google/genai';
import { TranscriptionTurn } from '../types';

// --- AUDIO HELPER FUNCTIONS ---

function encode(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

function createBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}


// --- FUNCTION DECLARATIONS for GOOGLE SERVICES ---

const functionDeclarations: FunctionDeclaration[] = [
    {
        name: 'searchGmail',
        parameters: {
            type: Type.OBJECT,
            description: 'Busca correos en la bandeja de entrada del usuario.',
            properties: {
                query: { type: Type.STRING, description: 'Términos de búsqueda, por ejemplo: "facturas de aws"' },
            },
            required: ['query'],
        },
    },
    {
        name: 'createCalendarEvent',
        parameters: {
            type: Type.OBJECT,
            description: 'Crea un nuevo evento en el calendario del usuario.',
            properties: {
                title: { type: Type.STRING, description: 'El título del evento.' },
                date: { type: Type.STRING, description: 'La fecha del evento en formato AAAA-MM-DD.' },
                time: { type: Type.STRING, description: 'La hora del evento en formato HH:MM.' },
                durationMinutes: { type: Type.NUMBER, description: 'Duración en minutos.' },
                attendees: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'Lista de correos de los asistentes.' },
            },
            required: ['title', 'date', 'time'],
        },
    },
    {
        name: 'saveInteractionToDrive',
        parameters: {
            type: Type.OBJECT,
            description: 'Guarda la transcripción de la conversación actual en Google Drive.',
            properties: {
                fileName: { type: Type.STRING, description: 'Nombre del archivo para guardar la conversación.' },
                tags: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'Etiquetas para organizar la nota, ej: "correo", "proyecto", "personal".' }
            },
            required: ['fileName', 'tags'],
        },
    },
    {
        name: 'searchWeb',
        parameters: {
            type: Type.OBJECT,
            description: 'Realiza una búsqueda en internet.',
            properties: {
                query: { type: Type.STRING, description: 'La pregunta o términos a buscar.' },
            },
            required: ['query'],
        }
    }
];

// --- GEMINI SERVICE CLASS ---

export class GeminiService {
    private ai: GoogleGenAI;
    private sessionPromise: Promise<LiveSession> | null = null;
    private onSessionCreated: (session: LiveSession) => void;

    // Audio Playback state
    private outputAudioContext: AudioContext;
    private nextStartTime = 0;
    private audioSources = new Set<AudioBufferSourceNode>();


    constructor(ai: GoogleGenAI, onSessionCreated: (session: LiveSession) => void) {
        this.ai = ai;
        this.onSessionCreated = onSessionCreated;
        this.outputAudioContext = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 24000 });
    }

    public async startSession(onMessage: (message: LiveServerMessage) => void): Promise<void> {
        this.sessionPromise = this.ai.live.connect({
            model: 'gemini-2.5-flash-native-audio-preview-09-2025',
            callbacks: {
                onopen: () => console.log('Session opened.'),
                onmessage: (message: LiveServerMessage) => {
                    onMessage(message);
                    this.handleAudioPlayback(message);
                },
                onerror: (e: ErrorEvent) => console.error('Session error:', e),
                onclose: (e: CloseEvent) => console.log('Session closed.'),
            },
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
                systemInstruction: 'Eres Claudia, una asistente de IA personal, amigable y muy eficiente. Tu objetivo es ayudar al usuario a organizar su vida digital y personal. Responde en español. Tienes acceso a sus servicios de Google. Sé concisa y proactiva. Al dar asistencia psicológica, sé empática y ofrece estructurar los pensamientos del usuario en proyectos o tareas manejables.',
                inputAudioTranscription: {},
                outputAudioTranscription: {},
                tools: [{ functionDeclarations: functionDeclarations }],
            },
        });
        
        const session = await this.sessionPromise;
        this.onSessionCreated(session);
    }
    
    private async handleAudioPlayback(message: LiveServerMessage) {
        const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
        if (base64Audio) {
            this.nextStartTime = Math.max(this.nextStartTime, this.outputAudioContext.currentTime);
            const audioBuffer = await decodeAudioData(decode(base64Audio), this.outputAudioContext, 24000, 1);
            const source = this.outputAudioContext.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(this.outputAudioContext.destination);
            source.addEventListener('ended', () => {
                this.audioSources.delete(source);
            });
            source.start(this.nextStartTime);
            this.nextStartTime += audioBuffer.duration;
            this.audioSources.add(source);
        }

        if (message.serverContent?.interrupted) {
            this.stopPlayback();
        }
    }
    
    public stopPlayback() {
        for (const source of this.audioSources.values()) {
            source.stop();
        }
        this.audioSources.clear();
        this.nextStartTime = 0;
    }

    public sendAudio(audioData: Float32Array) {
        if (!this.sessionPromise) return;
        const pcmBlob = createBlob(audioData);
        this.sessionPromise.then(session => {
            session.sendRealtimeInput({ media: pcmBlob });
        }).catch(err => console.error("Error sending audio:", err));
    }
    
    public async handleToolCall(toolCall: ToolCall, transcriptionHistory: TranscriptionTurn[]) {
        if (!this.sessionPromise) return;

        // Fix: Use window.gapi to access Google API client
        if (!window.gapi.client.getToken()) {
            const result = "Por favor, inicia sesión con tu cuenta de Google para usar esta función.";
            console.error(result);
             const session = await this.sessionPromise;
            session.sendToolResponse({
                functionResponses: {
                    id: toolCall.functionCalls[0].id,
                    name: toolCall.functionCalls[0].name,
                    response: { result: result },
                }
            });
            return;
        }

        for (const fc of toolCall.functionCalls) {
            console.log(`Tool call received: ${fc.name}`, fc.args);
            
            let result: string;
            try {
                switch(fc.name) {
                    case 'searchGmail':
                        // Fix: Use window.gapi to access Google API client
                        const gmailResponse = await window.gapi.client.gmail.users.messages.list({
                            'userId': 'me',
                            'q': fc.args.query,
                            'maxResults': 5,
                        });
                        const messages = gmailResponse.result.messages || [];
                        if (messages.length > 0) {
                            result = `Encontré ${messages.length} correos sobre "${fc.args.query}".`;
                        } else {
                            result = `No encontré correos que coincidan con "${fc.args.query}".`;
                        }
                        break;
                    case 'createCalendarEvent':
                        const event = {
                          'summary': fc.args.title,
                          'start': {
                            'dateTime': new Date(`${fc.args.date}T${fc.args.time}`).toISOString(),
                          },
                          'end': {
                            'dateTime': new Date(new Date(`${fc.args.date}T${fc.args.time}`).getTime() + (fc.args.durationMinutes || 60) * 60000).toISOString(),
                          },
                          'attendees': (fc.args.attendees || []).map((email: string) => ({'email': email})),
                        };
                        // Fix: Use window.gapi to access Google API client
                        await window.gapi.client.calendar.events.insert({
                            'calendarId': 'primary',
                            'resource': event
                        });
                        result = `¡Listo! El evento "${fc.args.title}" ha sido creado en tu calendario.`;
                        break;
                    case 'saveInteractionToDrive':
                        const transcript = transcriptionHistory.map(t => `[${new Date(t.timestamp).toLocaleTimeString()}] ${t.participant}: ${t.text}`).join('\n');
                        const fileMetadata = {
                            'name': `${fc.args.fileName}.txt`,
                            'parents': ['root']
                        };
                        const boundary = '-------314159265358979323846';
                        const delimiter = "\r\n--" + boundary + "\r\n";
                        const close_delim = "\r\n--" + boundary + "--";
                        const multipartRequestBody =
                            delimiter +
                            'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
                            JSON.stringify(fileMetadata) +
                            delimiter +
                            'Content-Type: text/plain\r\n\r\n' +
                            transcript +
                            close_delim;
                        // Fix: Use window.gapi to access Google API client
                        await window.gapi.client.request({
                            'path': 'https://www.googleapis.com/upload/drive/v3/files',
                            'method': 'POST',
                            'params': {'uploadType': 'multipart'},
                            'headers': {'Content-Type': 'multipart/related; boundary="' + boundary + '"'},
                            'body': multipartRequestBody
                        });
                        result = `Conversación guardada como "${fc.args.fileName}" en tu Google Drive.`;
                        break;
                    case 'searchWeb':
                         result = `Resultado simulado de búsqueda web para "${fc.args.query}": El primer resultado indica que...`;
                        break;
                    default:
                        result = `Herramienta ${fc.name} no reconocida.`;
                }
            } catch (error: any) {
                console.error(`Error executing tool ${fc.name}:`, error);
                result = `Lo siento, hubo un error al usar la herramienta ${fc.name}. El error fue: ${error.result?.error?.message || error.message || 'Error desconocido'}`;
            }

            const session = await this.sessionPromise;
            session.sendToolResponse({
                functionResponses: {
                    id: fc.id,
                    name: fc.name,
                    response: { result: result },
                }
            });
        }
    }
}
