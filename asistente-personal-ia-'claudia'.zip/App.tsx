import React, { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleGenAI, LiveSession, LiveServerMessage } from '@google/genai';

import { MicrophoneButton } from './components/MicrophoneButton';
import { TranscriptionView } from './components/TranscriptionView';
import { ProjectsPanel } from './components/ProjectsPanel';
import { SaveInteractionModal } from './components/SaveInteractionModal';
import { Header } from './components/Header';
import { StatusIndicator } from './components/StatusIndicator';
import { GeminiService } from './services/geminiService';
import type { TranscriptionTurn, Project } from './types';
import { ConversationParticipant, SessionState } from './types';
import { AuthScreen } from './components/AuthScreen';

export default function App() {
    const [sessionState, setSessionState] = useState<SessionState>(SessionState.IDLE);
    const [transcriptionHistory, setTranscriptionHistory] = useState<TranscriptionTurn[]>([]);
    const [currentInput, setCurrentInput] = useState('');
    const [currentOutput, setCurrentOutput] = useState('');
    const [showSaveModal, setShowSaveModal] = useState(false);
    const [projects, setProjects] = useState<Project[]>([
        { id: 'proj-1', name: 'Lanzamiento de Producto Q3', description: 'Coordinar el lanzamiento del nuevo widget.', tasks: ['Definir estrategia de marketing', 'Finalizar diseño de empaque'], lastUpdated: new Date().toISOString() },
        { id: 'proj-2', name: 'Desarrollo Personal: React Avanzado', description: 'Mejorar habilidades en React y TypeScript.', tasks: ['Completar curso de hooks avanzados', 'Construir 3 proyectos de portafolio'], lastUpdated: new Date().toISOString() },
    ]);
    const [isGoogleReady, setIsGoogleReady] = useState(false);
    const [isSignedIn, setIsSignedIn] = useState(false);

    const geminiServiceRef = useRef<GeminiService | null>(null);
    const sessionRef = useRef<LiveSession | null>(null);
    const mediaStreamRef = useRef<MediaStream | null>(null);
    const audioContextRef = useRef<AudioContext | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
    const tokenClient = useRef<any>(null);

    useEffect(() => {
        const gapiScript = document.createElement('script');
        gapiScript.src = 'https://apis.google.com/js/api.js';
        gapiScript.async = true;
        gapiScript.defer = true;
        document.body.appendChild(gapiScript);
    
        const gisScript = document.createElement('script');
        gisScript.src = 'https://accounts.google.com/gsi/client';
        gisScript.async = true;
        gisScript.defer = true;
        document.body.appendChild(gisScript);
    
        const checkGoogleApi = setInterval(() => {
            // Fix: Correctly check for gapi and google on the window object.
            if (window.gapi && window.google) {
                clearInterval(checkGoogleApi);
                window.gapi.load('client', () => {
                     window.gapi.client.init({
                        apiKey: process.env.GOOGLE_API_KEY,
                        discoveryDocs: [
                            "https://www.googleapis.com/discovery/v1/apis/gmail/v1/rest",
                            "https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest",
                            "https://www.googleapis.com/discovery/v1/apis/drive/v3/rest"
                        ],
                    }).then(() => {
                        tokenClient.current = window.google.accounts.oauth2.initTokenClient({
                            client_id: process.env.GOOGLE_CLIENT_ID,
                            scope: 'https://www.googleapis.com/auth/gmail.readonly https://www.googleapis.com/auth/calendar.events https://www.googleapis.com/auth/drive.file',
                            callback: (tokenResponse: any) => {
                                if (tokenResponse && tokenResponse.access_token) {
                                    window.gapi.client.setToken(tokenResponse);
                                    setIsSignedIn(true);
                                }
                            },
                        });
                        setIsGoogleReady(true);
                    }).catch((err: any) => console.error("Error initializing gapi client:", err));
                });
            }
        }, 100);

        return () => {
            clearInterval(checkGoogleApi);
            document.body.removeChild(gapiScript);
            document.body.removeChild(gisScript);
        };
    }, []);

    const onMessage = useCallback((message: LiveServerMessage) => {
        let historyUpdates: TranscriptionTurn[] = [];
        let finalInput = currentInput;
        let finalOutput = currentOutput;

        if (message.serverContent?.inputTranscription) {
            setCurrentInput(prev => prev + message.serverContent.inputTranscription.text);
        }
        if (message.serverContent?.outputTranscription) {
            setCurrentOutput(prev => prev + message.serverContent.outputTranscription.text);
        }

        if (message.serverContent?.turnComplete) {
            finalInput += (message.serverContent?.inputTranscription?.text || '');
            finalOutput += (message.serverContent?.outputTranscription?.text || '');

            if (finalInput.trim()) {
                historyUpdates.push({ participant: ConversationParticipant.USER, text: finalInput, timestamp: new Date() });
                 if (finalInput.toLowerCase().includes("eso es todo claudia gracias")) {
                    setShowSaveModal(true);
                }
            }
            if (finalOutput.trim()) {
                historyUpdates.push({ participant: ConversationParticipant.BOT, text: finalOutput, timestamp: new Date() });
            }
           
            setCurrentInput('');
            setCurrentOutput('');
        }

        if (message.toolCall) {
            const fullHistory = [...transcriptionHistory, ...historyUpdates];
            geminiServiceRef.current?.handleToolCall(message.toolCall, fullHistory);
            const toolCallText = `Ejecutando herramienta: ${message.toolCall.functionCalls[0].name}...`;
            historyUpdates.push({ participant: ConversationParticipant.SYSTEM, text: toolCallText, timestamp: new Date() });
        }

        if (historyUpdates.length > 0) {
            setTranscriptionHistory(prev => [...prev, ...historyUpdates]);
        }

    }, [currentInput, currentOutput, transcriptionHistory]);

    const stopListening = useCallback(async () => {
        setSessionState(SessionState.IDLE);

        if (sessionRef.current) {
            sessionRef.current.close();
            sessionRef.current = null;
        }

        if (mediaStreamRef.current) {
            mediaStreamRef.current.getTracks().forEach(track => track.stop());
            mediaStreamRef.current = null;
        }

        if (scriptProcessorRef.current) {
            scriptProcessorRef.current.disconnect();
            scriptProcessorRef.current = null;
        }

        if(mediaStreamSourceRef.current) {
            mediaStreamSourceRef.current.disconnect();
            mediaStreamSourceRef.current = null;
        }

        if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
            await audioContextRef.current.close();
            audioContextRef.current = null;
        }

        geminiServiceRef.current?.stopPlayback();
        geminiServiceRef.current = null;

    }, []);

    const startListening = useCallback(async () => {
        setSessionState(SessionState.CONNECTING);
        setTranscriptionHistory(prev => [...prev, { participant: ConversationParticipant.SYSTEM, text: 'Iniciando sesión...', timestamp: new Date() }]);
        
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const service = new GeminiService(ai, (session) => {
                sessionRef.current = session;
            });
            geminiServiceRef.current = service;

            audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 16000 });
            
            mediaStreamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });

            await service.startSession(onMessage);
            
            setSessionState(SessionState.LISTENING);
            
            const source = audioContextRef.current.createMediaStreamSource(mediaStreamRef.current);
            mediaStreamSourceRef.current = source;
            
            const scriptProcessor = audioContextRef.current.createScriptProcessor(4096, 1, 1);
            scriptProcessorRef.current = scriptProcessor;

            scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                service.sendAudio(inputData);
            };

            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextRef.current.destination);

        } catch (error) {
            console.error("Failed to start listening:", error);
            setTranscriptionHistory(prev => [...prev, { participant: ConversationParticipant.SYSTEM, text: `Error: ${error instanceof Error ? error.message : String(error)}`, timestamp: new Date() }]);
            await stopListening();
        }
    }, [onMessage, stopListening]);
    
    useEffect(() => {
        if(showSaveModal) {
            if(sessionState !== SessionState.IDLE) {
               stopListening();
            }
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [showSaveModal]);

    const handleMicButtonClick = () => {
        if (sessionState === SessionState.IDLE) {
            startListening();
        } else {
            stopListening();
        }
    };
    
    const handleSaveInteraction = (save: boolean) => {
        if (save) {
            const transcript = transcriptionHistory.map(t => `[${t.participant}] ${t.text}`).join('\n');
            geminiServiceRef.current?.handleToolCall({
                functionCalls: [{
                    name: 'saveInteractionToDrive',
                    args: { fileName: `Claudia-Chat-${new Date().toISOString()}`, content: transcript }
                }]
            }, transcriptionHistory);
        } else {
             setTranscriptionHistory(prev => [...prev, { participant: ConversationParticipant.SYSTEM, text: 'Interacción descartada.', timestamp: new Date() }]);
        }
        setShowSaveModal(false);
    };

    const handleSignIn = () => {
        if (tokenClient.current) {
            tokenClient.current.requestAccessToken();
        }
    };

    const handleSignOut = () => {
        // Fix: Use window.gapi to access Google API client
        const token = window.gapi.client.getToken();
        if (token) {
            // Fix: Use window.google to access Google identity services
            window.google.accounts.oauth2.revoke(token.access_token, () => {
                window.gapi.client.setToken(null);
                setIsSignedIn(false);
            });
        }
    };

    if (!isSignedIn) {
        return <AuthScreen onSignIn={handleSignIn} isReady={isGoogleReady} />;
    }

    return (
        <div className="bg-gray-900 text-white min-h-screen flex flex-col font-sans">
            <Header onSignOut={handleSignOut} />
            <main className="flex-grow flex flex-col md:flex-row p-4 gap-4 max-w-7xl mx-auto w-full">
                <div className="flex-grow flex flex-col bg-gray-800 rounded-lg shadow-2xl overflow-hidden">
                    <div className="p-4 border-b border-gray-700">
                         <h2 className="text-xl font-bold text-gray-200">Transcripción en Vivo</h2>
                         <StatusIndicator state={sessionState} />
                    </div>
                    <TranscriptionView 
                        history={transcriptionHistory}
                        currentInput={currentInput}
                        currentOutput={currentOutput}
                    />
                </div>
                <div className="w-full md:w-80 flex-shrink-0">
                    <ProjectsPanel projects={projects} />
                </div>
            </main>
            <footer className="sticky bottom-0 left-0 right-0 p-4 bg-gray-900/80 backdrop-blur-sm flex justify-center items-center">
                <MicrophoneButton state={sessionState} onClick={handleMicButtonClick} />
            </footer>
             {showSaveModal && <SaveInteractionModal onSave={handleSaveInteraction} />}
        </div>
    );
}
